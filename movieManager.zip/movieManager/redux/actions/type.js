export const SET_MOVIES = 'SET_MOVIES';
