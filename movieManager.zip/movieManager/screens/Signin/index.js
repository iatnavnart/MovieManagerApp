import React, {Component} from 'react';
import {Text, View} from 'react-native';

export class SigninScreen extends Component {
  render() {
    return (
      <View>
        <Text> asdhjkasdhk </Text>
      </View>
    );
  }
}

export default SigninScreen;
