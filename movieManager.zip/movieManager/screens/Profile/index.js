import React, {Component} from 'react';
import {Text, View, SafeAreaView} from 'react-native';

export class ProfileScreen extends Component {
  render() {
    return (
      <SafeAreaView>
        <Text> Profile </Text>
      </SafeAreaView>
    );
  }
}

export default ProfileScreen;
