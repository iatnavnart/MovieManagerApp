import React, {Component} from 'react';
import {Text, View} from 'react-native';

export class CreateMovieScreen extends Component {
  render() {
    return (
      <View>
        <Text> Form create Movie </Text>
      </View>
    );
  }
}

export default CreateMovieScreen;
